import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'

const CartContext = createContext(null)

function useLocalStorage(key, initial) {
  const [val, setVal] = useState(() => {
    try { return JSON.parse(localStorage.getItem(key)) ?? initial } catch { return initial }
  })
  useEffect(() => { localStorage.setItem(key, JSON.stringify(val)) }, [key, val])
  return [val, setVal]
}

export function CartProvider({ children }) {
  const [items, setItems] = useLocalStorage('edustream_cart', [])

  const add = (course) => {
    setItems(prev => {
      const found = prev.find(p => p.id === course.id)
      if (found) return prev.map(p => p.id === course.id ? { ...p, qty: p.qty + 1 } : p)
      return [...prev, { ...course, qty: 1 }]
    })
  }
  const remove = (id) => setItems(prev => prev.filter(p => p.id !== id))
  const dec = (id) => setItems(prev => prev.map(p => p.id === id ? { ...p, qty: Math.max(1, p.qty - 1) } : p))
  const inc = (id) => setItems(prev => prev.map(p => p.id === id ? { ...p, qty: p.qty + 1 } : p))
  const clear = () => setItems([])

  const total = useMemo(() => items.reduce((s, i) => s + i.price * i.qty, 0), [items])

  const value = useMemo(() => ({ items, add, remove, dec, inc, clear, total }), [items, total])
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() { return useContext(CartContext) }
