import React, { useEffect, useState } from 'react'
import Navbar from './components/Navbar'
import MediaGallery from './components/MediaGallery'
import Dashboard from './components/Dashboard'
import AuthForms from './components/AuthForms'
import Cart from './components/Cart'
import CourseList from './components/CourseList'
import { AuthProvider, useAuth } from './context/AuthContext'
import { CartProvider, useCart } from './context/CartContext'
import { api } from './mock/api'
import { Toaster, toast } from 'sonner'

function Courses() {
  const { add } = useCart()
  const [courses, setCourses] = useState([])
  useEffect(() => { api.listCourses().then(setCourses) }, [])
  return (
    <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {courses.map(c => (
        <div key={c.id} className="rounded-2xl border border-gray-200 dark:border-gray-800 p-4 bg-white dark:bg-gray-900">
          <div className="font-semibold">{c.title}</div>
          <div className="opacity-70 text-sm mb-3">₹ {c.price.toFixed(2)}</div>
          <button className="rounded-xl bg-indigo-600 text-white px-3 py-2" onClick={()=>add(c)}>Add to cart</button>
        </div>
        
        

      ))}
    </section>
  )
}

function Shell() {
  const [showAuth, setShowAuth] = useState(false)
  const [showCart, setShowCart] = useState(false)
  const { token } = useAuth()
  const { items, total, clear } = useCart()

  const checkout = async () => {
    try {
      const res = await api.purchase({ token, items })
      toast.success('Order placed: ' + res.orderId)
      clear()
    } catch (e) {
      toast.error(e.message)
      setShowAuth(true)
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar onShowCart={()=>setShowCart(true)} onShowAuth={()=>setShowAuth(true)} />
      <main className="max-w-6xl mx-auto px-4 py-6 space-y-10">
        <section className="rounded-2xl p-6 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 border border-gray-200 dark:border-gray-800">
          <h1 className="text-2xl font-bold">Welcome to EduStream</h1>
          <p className="opacity-80">Interactive courses, real-time feedback, secure purchases, and a customizable experience.</p>
          <div className="mt-4 flex gap-2">
            <button className="rounded-xl bg-indigo-600 text-white px-3 py-2" onClick={()=>setShowAuth(true)}>Get Started</button>
            <button className="rounded-xl bg-gray-100 dark:bg-gray-800 px-3 py-2" onClick={()=>setShowCart(true)}>View Cart</button>
            <button className="rounded-xl bg-emerald-600 text-white px-3 py-2" onClick={checkout}>Quick Checkout</button>
          </div>
        </section>

        <MediaGallery />
        <Courses />
        <Dashboard />

        <section className="rounded-2xl border border-gray-200 dark:border-gray-800 p-6 bg-white dark:bg-gray-900">
          <h3 className="font-semibold mb-2">Quiz (Real-time Validation)</h3>
          <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e)=>{e.preventDefault(); if(e.currentTarget.reportValidity()) toast.success('Quiz submitted!')}} noValidate>
            <div>
              <label className="text-sm">Your Name</label>
              <input required name="q_name" className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900" placeholder="Alice" />
            </div>
            <div>
              <label className="text-sm">Email</label>
              <input required type="email" name="q_email" className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900" placeholder="alice@example.com" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-sm">What does JWT stand for?</label>
              <input required name="q1" className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900" />
            </div>
            <button className="sm:col-span-2 rounded-xl bg-indigo-600 text-white px-3 py-2">Submit</button>
          </form>
        </section>
      </main>

      {showAuth && <AuthForms onClose={()=>setShowAuth(false)} />}
      {showCart && <Cart onClose={()=>setShowCart(false)} />}
    </div>

    
  )
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Shell />
        <Toaster richColors position="top-center" />
      </CartProvider>
    </AuthProvider>
  )
}
