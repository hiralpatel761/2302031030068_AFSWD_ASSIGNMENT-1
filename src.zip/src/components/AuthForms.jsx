import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { toast } from "sonner";

export default function AuthForms({ onClose }) {
  const [tab, setTab] = useState("login");

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-6">
        <div className="flex gap-2 mb-4">
          <button
            className={`px-3 py-2 rounded-xl ${
              tab === "login"
                ? "bg-indigo-600 text-white"
                : "bg-gray-100 dark:bg-gray-800"
            }`}
            onClick={() => setTab("login")}
          >
            Login
          </button>
          <button
            className={`px-3 py-2 rounded-xl ${
              tab === "register"
                ? "bg-indigo-600 text-white"
                : "bg-gray-100 dark:bg-gray-800"
            }`}
            onClick={() => setTab("register")}
          >
            Register
          </button>
          <button
            className="ml-auto px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800"
            onClick={onClose}
          >
            Close
          </button>
        </div>

        {tab === "login" ? (
          <LoginForm onSuccess={onClose} />
        ) : (
          <RegisterForm onSuccess={onClose} />
        )}
      </div>
    </div>
  );
}

function LoginForm({ onSuccess }) {
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.reportValidity()) return;

    const fd = new FormData(form);
    const email = fd.get("email");
    const password = fd.get("password");

    try {
      const res = await login(email, password);
      toast.success("Logged in as " + res.user.email);
      onSuccess?.();
    } catch (err) {
      toast.error(err.message || "Login failed");
    }
  };

  return (
    <form className="space-y-3" onSubmit={handleSubmit} noValidate>
      <div>
        <label className="text-sm">Email</label>
        <input
          name="email"
          type="email"
          required
          className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900"
          placeholder="you@edustream.io"
        />
      </div>
      <div>
        <label className="text-sm">Password</label>
        <input
          name="password"
          type="password"
          required
          minLength={6}
          className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900"
          placeholder="******"
        />
      </div>
      <button className="w-full rounded-xl bg-indigo-600 text-white px-3 py-2">
        Login
      </button>
    </form>
  );
}

function RegisterForm({ onSuccess }) {
  const { register } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.reportValidity()) return;

    const fd = new FormData(form);
    const payload = Object.fromEntries(fd.entries());

    if (payload.password !== payload.confirm) {
      toast.error("Passwords do not match");
      return;
    }

    try {
      const res = await register({
        email: payload.email,
        password: payload.password,
        name: payload.name,
      });
      toast.success("Welcome " + res.user.name);
      onSuccess?.();
    } catch (err) {
      toast.error(err.message || "Registration failed");
    }
  };

  return (
    <form className="space-y-3" onSubmit={handleSubmit} noValidate>
      <div>
        <label className="text-sm">Name</label>
        <input
          name="name"
          required
          className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900"
          placeholder="Your Name"
        />
      </div>
      <div>
        <label className="text-sm">Email</label>
        <input
          name="email"
          type="email"
          required
          className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900"
          placeholder="you@edustream.io"
        />
      </div>
      <div>
        <label className="text-sm">Password</label>
        <input
          name="password"
          type="password"
          required
          minLength={6}
          className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900"
          placeholder="******"
        />
      </div>
      <div>
        <label className="text-sm">Confirm Password</label>
        <input
          name="confirm"
          type="password"
          required
          minLength={6}
          className="mt-1 w-full rounded-xl border px-3 py-2 bg-white dark:bg-gray-900"
          placeholder="******"
        />
      </div>
      <button className="w-full rounded-xl bg-indigo-600 text-white px-3 py-2">
        Create account
      </button>
    </form>
  );
}
