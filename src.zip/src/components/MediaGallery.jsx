import React, { useEffect, useRef, useState } from 'react'
import { Play, Pause } from 'lucide-react'
import { toast } from 'sonner'

/** HTML5 media + Canvas overlay (progress + captions-like demo) */
export default function MediaGallery() {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    let raf = null

    function draw() {
      const w = canvas.width = canvas.clientWidth
      const h = canvas.height = canvas.clientHeight
      ctx.clearRect(0,0,w,h)
      // progress bar
      ctx.fillStyle = '#4f46e5'
      ctx.fillRect(0, h-8, (progress/100)*w, 8)
      // watermark overlay
      ctx.font = '16px sans-serif'
      ctx.fillStyle = 'rgba(0,0,0,0.6)'
      ctx.fillText('EduStream Overlay • Demo', 10, 22)
      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [progress])

  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    const onTime = () => {
      const p = (video.currentTime / video.duration) * 100 || 0
      setProgress(p)
    }
    const onPlay = () => { setPlaying(true); toast.success('Playback started') }
    const onPause = () => { setPlaying(false); toast.info('Paused') }
    video.addEventListener('timeupdate', onTime)
    video.addEventListener('play', onPlay)
    video.addEventListener('pause', onPause)
    return () => {
      video.removeEventListener('timeupdate', onTime)
      video.removeEventListener('play', onPlay)
      video.removeEventListener('pause', onPause)
    }
  }, [])

  const togglePlay = () => {
    const v = videoRef.current
    if (!v) return
    if (v.paused) v.play()
    else v.pause()
  }

  return (
    <section className="grid md:grid-cols-2 gap-6">
      <div className="relative rounded-2xl overflow-hidden border border-gray-200 dark:border-gray-800 bg-black aspect-video">
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"
          controls
          crossOrigin="anonymous"
        />
        <canvas ref={canvasRef} className="pointer-events-none absolute inset-0"></canvas>
        <button
          onClick={togglePlay}
          className="absolute bottom-3 left-3 bg-white/90 dark:bg-gray-800/90 rounded-xl px-3 py-2 flex items-center gap-2"
        >
          {playing ? <Pause className="w-4 h-4"/> : <Play className="w-4 h-4"/>}
          {playing ? 'Pause' : 'Play'}
        </button>
      </div>

      <div className="space-y-3">
        <h3 className="text-lg font-semibold">Media Gallery</h3>
        <p className="text-sm opacity-80">Showcasing HTML5 media with Canvas overlays and media events. Replace the sample URL with course videos stored via your CDN.</p>
        <audio controls className="w-full">
          <source src="https://www.kozco.com/tech/piano2-CoolEdit.mp3" type="audio/mpeg" />
        </audio>
      </div>
    </section>
  )
}
