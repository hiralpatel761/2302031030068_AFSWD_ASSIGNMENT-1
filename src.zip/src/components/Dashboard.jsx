import React from 'react'
import { ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, BarChart, Bar } from 'recharts'

const progressData = [
  { week: 'W1', progress: 10 },
  { week: 'W2', progress: 25 },
  { week: 'W3', progress: 45 },
  { week: 'W4', progress: 60 },
  { week: 'W5', progress: 80 },
  { week: 'W6', progress: 92 },
]

const timeData = [
  { course: 'React Basics', hours: 5 },
  { course: 'Laravel API', hours: 3 },
  { course: 'MongoDB', hours: 4 },
  { course: 'Tailwind', hours: 2 },
]

export default function Dashboard() {
  return (
    <section className="grid lg:grid-cols-2 gap-6">
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 p-4 bg-white dark:bg-gray-900">
        <h3 className="font-semibold mb-3">Weekly Progress</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={progressData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="progress" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 p-4 bg-white dark:bg-gray-900">
        <h3 className="font-semibold mb-3">Time Spent per Course (hrs)</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={timeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="course" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="hours" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </section>
  )
}
