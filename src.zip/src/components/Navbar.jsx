import React from 'react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import ThemeToggle from './ThemeToggle'
import { ShoppingCart, LogOut, User } from 'lucide-react'

export default function Navbar({ onShowCart, onShowAuth }) {
  const { user, logout } = useAuth()
  const { items } = useCart()

  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/70 dark:bg-gray-900/70 border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
        <div className="text-xl font-bold">EduStream</div>
        <nav className="ml-auto flex items-center gap-2">
          <ThemeToggle />
          <button className="relative rounded-xl px-3 py-2 bg-gray-100 dark:bg-gray-800" onClick={onShowCart}>
            <ShoppingCart className="inline w-5 h-5" />
            <span className="sr-only">Cart</span>
            {items.length > 0 && (
              <span className="absolute -top-1 -right-1 text-xs bg-indigo-600 text-white rounded-full px-1">
                {items.length}
              </span>
            )}
          </button>
          {user ? (
            <button className="rounded-xl px-3 py-2 bg-gray-100 dark:bg-gray-800 flex items-center gap-2" onClick={logout}>
              <LogOut className="w-5 h-5" /><span>Logout</span>
            </button>
          ) : (
            <button className="rounded-xl px-3 py-2 bg-gray-100 dark:bg-gray-800 flex items-center gap-2" onClick={onShowAuth}>
              <User className="w-5 h-5" /><span>Login</span>
            </button>
          )}
        </nav>
      </div>
    </header>
  )
}
