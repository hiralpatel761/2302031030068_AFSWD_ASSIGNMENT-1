import React from 'react'
import { useCart } from '../context/CartContext'
import { Minus, Plus, Trash2 } from 'lucide-react'

export default function Cart({ onClose }) {
  const { items, inc, dec, remove, total, clear } = useCart()
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-6">
        <div className="flex items-center mb-4">
          <h3 className="text-lg font-semibold">Shopping Cart</h3>
          <button className="ml-auto px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800" onClick={onClose}>Close</button>
        </div>
        <div className="space-y-3 max-h-80 overflow-auto pr-2">
          {items.length === 0 && <p className="opacity-70">Your cart is empty.</p>}
          {items.map(it => (
            <div key={it.id} className="flex items-center gap-3 border rounded-xl p-3">
              <div className="flex-1">
                <div className="font-medium">{it.title}</div>
                <div className="text-sm opacity-70">₹ {it.price.toFixed(2)}</div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 rounded-xl bg-gray-100 dark:bg-gray-800" onClick={()=>dec(it.id)}><Minus className="w-4 h-4"/></button>
                <span>{it.qty}</span>
                <button className="p-2 rounded-xl bg-gray-100 dark:bg-gray-800" onClick={()=>inc(it.id)}><Plus className="w-4 h-4"/></button>
              </div>
              <button className="p-2 rounded-xl bg-red-100 dark:bg-red-900/40 text-red-600" onClick={()=>remove(it.id)}><Trash2 className="w-4 h-4"/></button>
            </div>
          ))}
        </div>
        <div className="flex items-center mt-4">
          <div className="font-semibold">Total: ₹ {total.toFixed(2)}</div>
          <button className="ml-auto px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800" onClick={clear}>Clear</button>
          <button className="ml-2 px-3 py-2 rounded-xl bg-indigo-600 text-white">Checkout</button>
        </div>
      </div>
    </div>
  )
}
