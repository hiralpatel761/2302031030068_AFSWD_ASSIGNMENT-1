// Swap these functions with your Laravel API endpoints.
// Example Laravel stack: Laravel + Sanctum/JWT + MongoDB models (User, Course, Order).
// Use job queues for emails/uploads; here we just simulate.

const sleep = (ms) => new Promise(r => setTimeout(r, ms))

const demoCourses = [
  { id: 'c1', title: 'React Basics', price: 1299 },
  { id: 'c2', title: 'Laravel API with MongoDB', price: 1499 },
  { id: 'c3', title: 'Tailwind & UI Systems', price: 999 },
]

export const api = {
  async login({ email, password }) {
    await sleep(600)
    if (!email || !password) throw new Error('Missing credentials')
    // Simulated JWT
    return { token: 'demo-jwt-token', user: { id: 'u1', email, name: email.split('@')[0] } }
  },
  async register({ email, password, name }) {
    await sleep(800)
    return { token: 'demo-jwt-token', user: { id: 'u2', email, name } }
  },
  async listCourses() {
    await sleep(300)
    return demoCourses
  },
  // Simulate background task trigger (e.g., queue email job)
  async purchase({ token, items }) {
    await sleep(800)
    if (!token) throw new Error('Unauthenticated')
    return { ok: true, orderId: 'ord_' + Math.random().toString(36).slice(2,8) }
  }
}
