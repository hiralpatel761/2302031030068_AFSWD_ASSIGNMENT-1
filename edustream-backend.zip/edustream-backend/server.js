import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import userRoutes from "./routes/userRoutrs.js";

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/users", userRoutes);

mongoose.connect("mongodb://127.0.0.1:27017/edustream")
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.log("❌ MongoDB connection error:", err));

app.get("/", (req, res) => res.send("EduStream backend is running 🚀"));

app.listen(4000, () => console.log("Backend running on http://localhost:4000"));
